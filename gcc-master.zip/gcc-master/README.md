GCC / group computer control란? 사내 및 교내에서 다중의 컴퓨터를 관리 및 제어하는 프로그램이다.
