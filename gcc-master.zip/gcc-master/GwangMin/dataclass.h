#ifndef DATACLASS_H
#define DATACLASS_H
class dataclass{

public:
    int flag;
};



#endif // DATACLASS_H
