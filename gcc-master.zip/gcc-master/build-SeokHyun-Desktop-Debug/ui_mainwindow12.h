/********************************************************************************
** Form generated from reading UI file 'mainwindow12.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW12_H
#define UI_MAINWINDOW12_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow12
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow12)
    {
        if (MainWindow12->objectName().isEmpty())
            MainWindow12->setObjectName(QStringLiteral("MainWindow12"));
        MainWindow12->resize(800, 600);
        centralwidget = new QWidget(MainWindow12);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(40, 50, 113, 25));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 50, 89, 25));
        MainWindow12->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow12);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainWindow12->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow12);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow12->setStatusBar(statusbar);

        retranslateUi(MainWindow12);

        QMetaObject::connectSlotsByName(MainWindow12);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow12)
    {
        MainWindow12->setWindowTitle(QApplication::translate("MainWindow12", "MainWindow", 0));
        pushButton->setText(QApplication::translate("MainWindow12", "PushButton", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow12: public Ui_MainWindow12 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW12_H
