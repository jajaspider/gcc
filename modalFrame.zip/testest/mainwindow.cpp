#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Dialog dialog(this);
    dialog.exec();
    qDebug() <<dialog.getNumber();
}

MainWindow::~MainWindow()
{
    delete ui;
}
